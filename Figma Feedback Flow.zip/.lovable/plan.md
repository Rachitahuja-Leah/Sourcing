## Scope

Single-file changes across `src/routes/index.tsx`, `src/routes/events.$id.tsx`, `src/routes/sourcing.new.tsx`, and `src/routes/events_.$id.review.$vendor.tsx`. Pure UI / mock-data work — no backend.

---

## 1. Item Code + Category (L1 › L2 › L3) on every item table

**Data model (mock):**
```ts
type Item = {
  code: string;        // e.g. "ITM-100245"
  name: string;
  l1: string; l2: string; l3: string;   // e.g. "Raw Materials" › "Metals" › "SS 304 Seamless Pipe"
  ...existing fields
}
```

**Display:** single `Category` column rendered as breadcrumb
`Raw Materials › Metals › SS 304` (muted separators, sortable on L1).
New `Item Code` column (mono font, e.g. `ITM-100245`) added before `Name`.

**Tables updated:**
- `index.tsx` → PR table (`PRTable`)
- `index.tsx` → `ConsolidationItemsModal` line-items list
- `events.$id.tsx` → `LineItemsTab`
- `events.$id.tsx` → all per-round price tables inside the negotiation view (line-item rows)
- `events.$id.tsx` → `VendorComparisonModal` price-comparison rows
- `sourcing.new.tsx` → item picker / RFP line-items step (whichever tables show items)
- `events_.$id.review.$vendor.tsx` → vendor submission line items

Seed data extended with `code`, `l1`, `l2`, `l3` (sample taxonomy: Raw Materials › Metals › SS 304 / Carbon Steel; Equipment › Assembly › Hydraulic Press; Safety › PPE › Helmets; IT › Hardware › Laptops; etc.).

---

## 2. Supplier name = hyperlink (styling only, no-op)

Every place a supplier/vendor name renders (PR table where applicable, event Suppliers/Vendors table, negotiation header, Q&A log, comparison modal, PO drafts, contract modal, invite modal) wraps the name in a styled `<a role="link">` — accent color, underline on hover, `cursor-pointer`. Click is a no-op (`onClick` prevents default) so we don't introduce dead routes.

---

## 3. Supplier Risk Score + Performance Score

Extend `VendorRow`:
```ts
type VendorRow = {
  ...
  riskScore: number;          // 0–100, higher = riskier
  performanceScore: number | null;  // 0–100; null renders "N/A"
}
```

Two new columns in the Vendors/Suppliers table on `events.$id.tsx`:
- **Risk Score** — number + colored band (0–33 green / 34–66 amber / 67–100 red)
- **Performance Score** — number + colored band (≥75 green / 50–74 amber / <50 red); `null` → muted `N/A — not yet rated`

Seed: mix realistic values; 2–3 vendors get `performanceScore: null`.

---

## 4. Active Sourcing Events → table view

Replace `EmptyEvents` cards in `index.tsx` with a `SourcingEventsTable` matching the attached screenshot.

**Columns:** Event / ID · Source · Category (L1 breadcrumb) · Suppliers (avatar + "+N Invited") · Value · Status · row-actions (`⋮`).

**Event ID format:** `SO011445` (prefix `SO` + 6 digits, monospace under the event name).

**Sample rows (~8):** SS Pipe Consolidated RFP, Valve Supply Renewal 2026, Boiler Tubes & CS Fittings, Spare Parts Q2 Procurement, Networking Equipment Tender Q1 2027, Mobile Devices RFQ Q3 2026, Data Center Infrastructure RFQ Q2 2026, Security Systems RFQ Q4 2026 — with mixed `Source` (PR Consolidation / Contract Renewal / Intake Request), categories, and `Status` pills (Open RFP / Awarded / Evaluating / Rejected).

Filter pills (Categories / Date created / Value / Stage) and pagination reuse existing `FilterPill` / `Pagination` components. The first row links to the existing `/events/$id` route (id `steel-materials-q2`); others are visual-only.

`StatsRow` continues to render above both tabs (unchanged).

---

## Technical notes

- Breadcrumb renderer: small `<CategoryPath l1 l2 l3 />` helper added once in each route file (or shared in `src/lib/utils.ts` if cleaner — TBD during implementation; leaning on per-file helper to avoid touching shared modules).
- Score band helper: `scoreBand(value, kind: 'risk' | 'perf')` returns `{ color, label }`.
- No new routes, no backend, no schema changes, no auth.
- Out of scope: a real Supplier Profile page, real category taxonomy management, real scoring logic.
